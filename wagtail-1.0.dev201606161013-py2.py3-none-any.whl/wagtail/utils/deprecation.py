class RemovedInWagtail11Warning(DeprecationWarning):
    pass


class RemovedInWagtail12Warning(PendingDeprecationWarning):
    pass
