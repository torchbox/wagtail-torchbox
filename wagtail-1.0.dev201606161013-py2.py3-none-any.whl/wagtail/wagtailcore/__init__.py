__version__ = '1.0.dev201606161013'
default_app_config = 'wagtail.wagtailcore.apps.WagtailCoreAppConfig'
