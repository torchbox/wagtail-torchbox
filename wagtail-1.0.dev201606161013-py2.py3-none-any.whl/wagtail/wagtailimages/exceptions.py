class InvalidFilterSpecError(ValueError):
    pass
