default_app_config = 'wagtail.wagtaildocs.apps.WagtailDocsAppConfig'
