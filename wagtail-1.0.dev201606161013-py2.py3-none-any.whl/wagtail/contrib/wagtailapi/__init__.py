default_app_config = 'wagtail.contrib.wagtailapi.apps.WagtailAPIAppConfig'
