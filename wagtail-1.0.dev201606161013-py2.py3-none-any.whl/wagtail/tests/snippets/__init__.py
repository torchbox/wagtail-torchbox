default_app_config = 'wagtail.tests.snippets.apps.WagtailSnippetsTestsAppConfig'
