default_app_config = 'wagtail.wagtailadmin.apps.WagtailAdminAppConfig'
