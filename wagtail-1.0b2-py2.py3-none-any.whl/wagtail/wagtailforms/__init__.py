default_app_config = 'wagtail.wagtailforms.apps.WagtailFormsAppConfig'
