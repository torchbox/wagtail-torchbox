__version__ = '1.0b2'
default_app_config = 'wagtail.wagtailcore.apps.WagtailCoreAppConfig'
