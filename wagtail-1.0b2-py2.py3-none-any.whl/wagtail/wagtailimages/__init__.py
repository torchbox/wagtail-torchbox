default_app_config = 'wagtail.wagtailimages.apps.WagtailImagesAppConfig'
