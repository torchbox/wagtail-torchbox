default_app_config = 'wagtail.wagtailembeds.apps.WagtailEmbedsAppConfig'
