default_app_config = 'wagtail.tests.testapp.apps.WagtailTestsAppConfig'
