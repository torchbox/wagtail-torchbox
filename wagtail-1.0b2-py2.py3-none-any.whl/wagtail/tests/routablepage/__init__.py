default_app_config = 'wagtail.tests.routablepage.apps.WagtailRoutablePageTestsAppConfig'
